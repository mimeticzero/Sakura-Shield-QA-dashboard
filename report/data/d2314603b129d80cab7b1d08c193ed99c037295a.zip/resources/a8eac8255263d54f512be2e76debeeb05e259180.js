// ============================================================
// SakuraRewards Service Worker
// Strategy:
//   - _next/static assets → Cache-first (immutable)
//   - /play/* HTML pages  → Network-first, fallback to cache
//   - Everything else     → Network-only (pass-through)
//
// Authenticated/dynamic pages (dashboard, onboarding, API…)
// are intentionally NOT cached — they require live auth state.
//
// Background Sync: offline spins are queued in IndexedDB by the
// client and replayed via /api/offline-sync when connectivity returns.
// ============================================================

const CACHE_VERSION = 'sakura-v1.3'
const STATIC_CACHE  = `${CACHE_VERSION}-static`
const PAGE_CACHE    = `${CACHE_VERSION}-pages`
const ALL_CACHES    = [STATIC_CACHE, PAGE_CACHE]

// ── IndexedDB constants (mirrored from src/lib/offline-queue.ts) ──
const OFFLINE_DB_NAME  = 'sakura-offline'
const OFFLINE_DB_VER   = 1
const OFFLINE_STORE    = 'spin-queue'

// ──────────────────────────────────────────────
// INSTALL — skip waiting, no precache needed
// ──────────────────────────────────────────────
self.addEventListener('install', () => {
  self.skipWaiting()
})

// ──────────────────────────────────────────────
// ACTIVATE — clean up old caches
// ──────────────────────────────────────────────
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) =>
        Promise.all(keys.filter((k) => !ALL_CACHES.includes(k)).map((k) => caches.delete(k)))
      )
      .then(() => self.clients.claim())
  )
})

// ──────────────────────────────────────────────
// FETCH — routing logic
// ──────────────────────────────────────────────
self.addEventListener('fetch', (event) => {
  const { request } = event
  const url = new URL(request.url)

  // Only handle GET requests from same origin
  if (request.method !== 'GET') return
  if (url.origin !== self.location.origin) return

  // ── Next.js static chunks: Cache-first ──────
  // These are content-hashed and immutable.
  if (url.pathname.startsWith('/_next/static/')) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached
        return fetch(request).then((response) => {
          if (response.ok) {
            // Clone SYNCHRONOUSLY before any async work — once the outer
            // .then resolves and the caller starts reading the body,
            // calling .clone() on the original would throw.
            const toCache = response.clone()
            caches.open(STATIC_CACHE).then((cache) => cache.put(request, toCache))
          }
          return response
        })
      })
    )
    return
  }

  // ── /play/* pages: Network-first with offline fallback ──
  // Employee game pages should work offline after first load.
  if (url.pathname.startsWith('/play')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.ok) {
            const toCache = response.clone()
            caches.open(PAGE_CACHE).then((cache) => cache.put(request, toCache))
          }
          return response
        })
        .catch(() =>
          caches.match(request).then(
            (cached) =>
              cached ||
              new Response(
                `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SakuraRewards — Offline</title>
  <style>
    body { margin:0; background:#0A0A0B; color:#FFB7C5; font-family:monospace;
           display:flex; align-items:center; justify-content:center; min-height:100vh; text-align:center; }
    p { color:rgba(255,255,255,0.4); font-size:0.8rem; margin:4px 0; }
  </style>
</head>
<body>
  <div>
    <div style="font-size:2.5rem;margin-bottom:16px">✦</div>
    <h1 style="font-size:1.1rem;margin:0 0 12px">Connexion requise · No connection · 无网络连接</h1>
    <p>Vérifiez votre réseau et réessayez.</p>
    <p>Check your network and try again.</p>
    <p>请检查网络后重试。</p>
  </div>
</body>
</html>`,
                { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } }
              )
          )
        )
    )
    return
  }

  // ── Everything else: Network-only (pass-through) ─────────
  // Dashboard, API routes, auth pages — all require live
  // server state and must never be served from cache.
  // We deliberately do NOT call event.respondWith() here,
  // which lets the browser handle the request natively.
})

// ──────────────────────────────────────────────
// BACKGROUND SYNC — replay offline spins
// Fires when connectivity returns (even if the tab is closed).
// Falls back to the `online` event handler in the client if
// SyncManager is not supported (Firefox).
// ──────────────────────────────────────────────
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-offline-spins') {
    event.waitUntil(flushOfflineSpins())
  }
})

function openOfflineDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(OFFLINE_DB_NAME, OFFLINE_DB_VER)
    req.onupgradeneeded = () => {
      req.result.createObjectStore(OFFLINE_STORE, { keyPath: 'id' })
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror   = () => reject(req.error)
  })
}

async function flushOfflineSpins() {
  let db
  try { db = await openOfflineDb() } catch { return }

  const spins = await new Promise((resolve, reject) => {
    const tx  = db.transaction(OFFLINE_STORE, 'readonly')
    const req = tx.objectStore(OFFLINE_STORE).getAll()
    req.onsuccess = () => resolve(req.result)
    req.onerror   = () => reject(req.error)
  })

  if (!spins || spins.length === 0) { db.close(); return }

  await Promise.allSettled(spins.map(async (spin) => {
    try {
      const res = await fetch('/api/offline-sync', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(spin),
      })
      // 200 OK or 409 Already synced → remove from queue
      if (res.ok || res.status === 409) {
        await new Promise((resolve, reject) => {
          const tx  = db.transaction(OFFLINE_STORE, 'readwrite')
          const req = tx.objectStore(OFFLINE_STORE).delete(spin.id)
          req.onsuccess = () => resolve()
          req.onerror   = () => reject(req.error)
        })
      }
    } catch {
      // Still offline — leave in queue, sync event will fire again
    }
  }))

  db.close()
}
