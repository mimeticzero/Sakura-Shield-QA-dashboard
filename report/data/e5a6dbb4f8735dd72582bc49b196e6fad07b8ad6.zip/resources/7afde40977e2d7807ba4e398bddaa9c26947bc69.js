/* SakuraFidelity Service Worker */
const CACHE_NAME  = 'sakura-v1'
const STATIC_EXT  = /\.(js|css|woff2?|png|jpg|svg|ico|webp)$/

// ── Install: cache static shell ──────────────────────────────────────────────
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll([
        '/manifest.json',
        '/api/icon/192',
        '/api/icon/512',
      ]).catch(() => {}))
      .then(() => self.skipWaiting()),
  )
})

// ── Activate: delete old caches ──────────────────────────────────────────────
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)),
      ))
      .then(() => self.clients.claim()),
  )
})

// ── Fetch strategy ───────────────────────────────────────────────────────────
self.addEventListener('fetch', event => {
  const { request } = event
  const url = new URL(request.url)

  // Only handle same-origin GET requests
  if (request.method !== 'GET') return
  if (url.origin !== self.location.origin) return

  // /_next/static & icons  → cache-first (immutable assets)
  if (url.pathname.startsWith('/_next/static/') || STATIC_EXT.test(url.pathname)) {
    event.respondWith(
      caches.match(request).then(cached => {
        if (cached) return cached
        return fetch(request).then(res => {
          if (res.ok) {
            const clone = res.clone()
            caches.open(CACHE_NAME).then(c => c.put(request, clone))
          }
          return res
        })
      }),
    )
    return
  }

  // /api/* → network-first, cache for offline fallback (48 h stale is fine)
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then(res => {
          if (res.ok) {
            const clone = res.clone()
            caches.open(CACHE_NAME).then(c => c.put(request, clone))
          }
          return res
        })
        .catch(() => caches.match(request)),
    )
    return
  }

  // HTML pages → network-first, cache for offline
  event.respondWith(
    fetch(request)
      .then(res => {
        if (res.ok) {
          const clone = res.clone()
          caches.open(CACHE_NAME).then(c => c.put(request, clone))
        }
        return res
      })
      .catch(() => caches.match(request)),
  )
})

// ── Push notifications ───────────────────────────────────────────────────────
self.addEventListener('push', event => {
  if (!event.data) return
  let data = {}
  try { data = event.data.json() } catch { return }

  event.waitUntil(
    self.registration.showNotification(data.title ?? 'SakuraFidelity', {
      body:    data.body  ?? '',
      icon:    '/api/icon/192',
      badge:   '/api/icon/96',
      data:    { url: data.url ?? '/' },
      vibrate: [200, 100, 200],
      tag:     'sakura-points',
      renotify: true,
    }),
  )
})

self.addEventListener('notificationclick', event => {
  event.notification.close()
  const url = event.notification.data?.url ?? '/'
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      for (const c of list) {
        if (c.url.includes(url) && 'focus' in c) return c.focus()
      }
      return clients.openWindow(url)
    }),
  )
})
